package utilities;

public class Print {
    public static void print(Object object) {
        System.out.println(object);
    }
}
