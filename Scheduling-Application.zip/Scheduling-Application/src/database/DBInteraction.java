package database;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import main.Main;

import java.sql.*;

/**
 * This class is a wrapper for SQL queries
 */
public class DBInteraction {
    /**
     * Updates the database
     * @param string The SQL query to be executed
     * @throws SQLException
     */
    public static void update(String string) throws SQLException {
        String splitString[] = string.split(" ", 2);
        try {
            Statement statement = DBConnection.getConnection().createStatement();
            if (splitString[0].equals("DELETE") || splitString[0].equals("INSERT") || splitString[0].equals("UPDATE")) {
                statement.executeUpdate(string);
            }
        } catch (SQLException e) {
            throw new SQLException("Cannot connect to the database!", e);
        }
    }

    /**
     * Performs a SELECT query on the database
     * @param string The SQL query to be executed
     * @return The result of the SQL query
     * @throws SQLException
     */
    public static ObservableList<Object> query(String string) throws SQLException {
        ObservableList<Object> rowResults = null;

        try {
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(string);
            ResultSet result = ps.executeQuery();
            ResultSetMetaData metadata = result.getMetaData();

            rowResults = FXCollections.observableArrayList();

            while (result.next()) {
                ObservableList<String> row = FXCollections.observableArrayList();
                for (int i = 1; i <= metadata.getColumnCount(); i++) {
                    row.add(result.getString(i));
                }
                rowResults.add(row);
            }
            return rowResults;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rowResults;
    }

    /**
     * Authenticates the user
     * @param string The SQL query to be executed
     * @return whether user was successfully authenticated
     * @throws SQLException
     */
    public static boolean auth(String string) throws SQLException {
        boolean toggle = false;
        try {
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(string);
            ResultSet result = ps.executeQuery();
            if (result.next() == true) {
                Main.username = result.getString("User_Name");
                Main.userID = Integer.valueOf(result.getString("User_ID"));
                toggle = true;
            }
        } catch (SQLException e) {
            throw new SQLException("Unable to authorize this user!", e);
        }
        return toggle;
    }
}
